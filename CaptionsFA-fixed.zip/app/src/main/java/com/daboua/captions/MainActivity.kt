package com.daboua.captions

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class Caption(
    val text: String,
    val start: Long,
    val end: Long,
    val highlight: Boolean = false
)

enum class CaptionStyle {
    PLAIN, BOX, WORDS, LARGE
}

class MainActivity : ComponentActivity() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var speechCallback: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CaptionsApp() }
    }

    fun startPersianSpeech(onText: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onText("")
            return
        }

        speechCallback = onText
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = Unit
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onError(error: Int) {
                    speechCallback?.invoke("")
                }
                override fun onResults(results: Bundle?) {
                    val values = results?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    speechCallback?.invoke(values?.firstOrNull().orEmpty())
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val values = partialResults?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    values?.firstOrNull()?.let { speechCallback?.invoke(it) }
                }
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startListening(intent)
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}

@Composable
fun CaptionsApp() {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val scope = rememberCoroutineScope()

    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var selected by remember { mutableIntStateOf(0) }
    var style by remember { mutableStateOf(CaptionStyle.PLAIN) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var seekRequest by remember { mutableLongStateOf(-1L) }
    var status by remember { mutableStateOf("ویدئو انتخاب نشده") }

    var captions by remember {
        mutableStateOf(
            listOf(
                Caption("اینجا متن زیرنویس قرار می‌گیرد", 0L, 3000L),
                Caption("برای شروع یک ویدئو انتخاب کنید", 3000L, 6000L)
            )
        )
    }

    val pickVideo = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) {
        it?.let {
            videoUri = it
            status = "ویدئو آماده است"
        }
    }

    val saveSrt = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(captionsToSrt(captions).toByteArray(Charsets.UTF_8))
                }
                status = "فایل SRT ذخیره شد"
            }.onFailure {
                status = "خطا در ذخیره SRT"
            }
        }
    }

    val requestAudioPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            activity?.startPersianSpeech { text ->
                if (text.isNotBlank()) {
                    captions = captions.replaceAt(
                        selected,
                        captions[selected].copy(text = text)
                    )
                    status = "متن فارسی دریافت شد"
                }
            }
        } else {
            status = "مجوز میکروفون داده نشد"
        }
    }

    fun startSpeech() {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            activity?.startPersianSpeech { text ->
                if (text.isNotBlank()) {
                    captions = captions.replaceAt(
                        selected,
                        captions[selected].copy(text = text)
                    )
                    status = "متن فارسی دریافت شد"
                }
            }
        } else {
            requestAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Captions FA") },
                    actions = {
                        IconButton(onClick = { saveSrt.launch("captions.srt") }) {
                            Icon(Icons.Default.Save, "ذخیره SRT")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0E0E0E))
                    .padding(padding)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(onClick = { pickVideo.launch("video/*") }) {
                        Text("انتخاب ویدئو")
                    }

                    OutlinedButton(
                        onClick = { startSpeech() },
                        enabled = captions.isNotEmpty()
                    ) {
                        Icon(Icons.Default.Mic, null)
                        Spacer(Modifier.width(6.dp))
                        Text("گفتار فارسی")
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 10.dp)
                ) {
                    if (videoUri != null) {
                        VideoPreview(
                            uri = videoUri!!,
                            seekRequest = seekRequest,
                            onPositionChanged = { currentPosition = it },
                            onDurationChanged = { duration = it }
                        )
                    } else {
                        Text(
                            "برای شروع یک ویدئو انتخاب کنید",
                            color = Color.Gray,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    if (captions.isNotEmpty()) {
                        val activeIndex = captions.indexOfLast {
                            currentPosition >= it.start && currentPosition < it.end
                        }.let { if (it >= 0) it else selected.coerceIn(0, captions.lastIndex) }

                        LaunchedEffect(activeIndex) {
                            if (activeIndex in captions.indices) selected = activeIndex
                        }

                        CaptionOverlay(
                            caption = captions[selected],
                            style = style,
                            progressInCaption = currentPosition - captions[selected].start,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(16.dp)
                        )
                    }
                }

                Text(
                    "$status  •  ${time(currentPosition)} / ${time(duration)}",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    textAlign = TextAlign.Center
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = {
                            if (captions.isNotEmpty()) {
                                captions = captions.replaceAt(
                                    selected,
                                    captions[selected].copy(
                                        highlight = !captions[selected].highlight
                                    )
                                )
                            }
                        },
                        enabled = captions.isNotEmpty()
                    ) {
                        Text("هایلایت")
                    }

                    Button(
                        onClick = {
                            style = when (style) {
                                CaptionStyle.PLAIN -> CaptionStyle.BOX
                                CaptionStyle.BOX -> CaptionStyle.WORDS
                                CaptionStyle.WORDS -> CaptionStyle.LARGE
                                CaptionStyle.LARGE -> CaptionStyle.PLAIN
                            }
                        },
                        enabled = captions.isNotEmpty()
                    ) {
                        Text("استایل")
                    }

                    Button(
                        onClick = {
                            if (captions.isEmpty()) return@Button
                            val item = captions[selected]
                            val newStart = item.end
                            val newEnd = (item.end + 2000L).coerceAtMost(
                                if (duration > 0) duration else item.end + 2000L
                            )
                            captions = captions.toMutableList().apply {
                                add(
                                    selected + 1,
                                    Caption("زیرنویس جدید", newStart, newEnd)
                                )
                            }.normalize()
                            selected = (selected + 1).coerceAtMost(captions.lastIndex)
                            seekRequest = captions[selected].start
                        },
                        enabled = captions.isNotEmpty()
                    ) {
                        Text("+ زیرنویس")
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 310.dp)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(captions, key = { index, _ -> index }) { index, caption ->
                        CaptionEditorCard(
                            index = index,
                            caption = caption,
                            selected = index == selected,
                            onSelect = {
                                selected = index
                                seekRequest = caption.start
                            },
                            onTextChange = { value ->
                                captions = captions.replaceAt(
                                    index,
                                    caption.copy(text = value)
                                )
                            },
                            onStartChange = { value ->
                                parseTime(value)?.let { start ->
                                    captions = captions.replaceAt(
                                        index,
                                        caption.copy(start = start.coerceAtLeast(0L))
                                    ).normalize()
                                }
                            },
                            onEndChange = { value ->
                                parseTime(value)?.let { end ->
                                    captions = captions.replaceAt(
                                        index,
                                        caption.copy(end = end.coerceAtLeast(caption.start + 100L))
                                    ).normalize()
                                }
                            },
                            onDelete = {
                                if (captions.size > 1) {
                                    captions = captions.toMutableList().apply { removeAt(index) }
                                    selected = selected.coerceIn(0, captions.lastIndex)
                                } else {
                                    status = "حداقل یک زیرنویس باید باقی بماند"
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoPreview(
    uri: Uri,
    seekRequest: Long,
    onPositionChanged: (Long) -> Unit,
    onDurationChanged: (Long) -> Unit
) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = false
        }
    }

    LaunchedEffect(player, seekRequest) {
        if (seekRequest >= 0L) player.seekTo(seekRequest)
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    onDurationChanged(player.duration.coerceAtLeast(0L))
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPositionChanged(player.currentPosition.coerceAtLeast(0L))
            }
        }
        player.addListener(listener)

        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player) {
        while (isActive) {
            onPositionChanged(player.currentPosition.coerceAtLeast(0L))
            if (player.duration > 0L) {
                onDurationChanged(player.duration)
            }
            delay(100)
        }
    }

    AndroidView(
        factory = {
            PlayerView(it).apply {
                this.player = player
                useController = true
                controllerShowTimeoutMs = 2000
            }
        },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun CaptionOverlay(
    caption: Caption,
    style: CaptionStyle,
    progressInCaption: Long,
    modifier: Modifier
) {
    val words = remember(caption.text) {
        caption.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    }

    val visibleText = if (style == CaptionStyle.WORDS && words.isNotEmpty()) {
        val duration = (caption.end - caption.start).coerceAtLeast(1L)
        val index = ((progressInCaption.coerceAtLeast(0L) * words.size) / duration)
            .toInt()
            .coerceIn(0, words.lastIndex)
        words.take(index + 1).joinToString(" ")
    } else {
        caption.text
    }

    val size = if (style == CaptionStyle.LARGE) 27.sp else 20.sp
    val background = if (style == CaptionStyle.BOX) {
        Color.Black.copy(alpha = .78f)
    } else {
        Color.Transparent
    }

    Text(
        text = visibleText,
        color = if (caption.highlight) Color(0xFFFFD54F) else Color.White,
        fontSize = size,
        textAlign = TextAlign.Center,
        modifier = modifier
            .background(background, RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

@Composable
private fun CaptionEditorCard(
    index: Int,
    caption: Caption,
    selected: Boolean,
    onSelect: () -> Unit,
    onTextChange: (String) -> Unit,
    onStartChange: (String) -> Unit,
    onEndChange: (String) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) Color(0xFF292929) else Color(0xFF191919)
        )
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "#${index + 1}",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = time(caption.start),
                    onValueChange = onStartChange,
                    label = { Text("شروع") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                OutlinedTextField(
                    value = time(caption.end),
                    onValueChange = onEndChange,
                    label = { Text("پایان") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "حذف")
                }
            }

            Spacer(Modifier.height(6.dp))

            OutlinedTextField(
                value = caption.text,
                onValueChange = onTextChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("متن زیرنویس") },
                minLines = 2
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onSelect) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(4.dp))
                    Text("برو به این زمان")
                }
            }
        }
    }
}

private fun List<Caption>.replaceAt(index: Int, value: Caption): List<Caption> =
    toMutableList().also { it[index] = value }

private fun List<Caption>.normalize(): List<Caption> {
    if (isEmpty()) return this
    return mapIndexed { index, item ->
        val start = item.start.coerceAtLeast(0L)
        val nextStart = getOrNull(index + 1)?.start
        val end = item.end.coerceAtLeast(start + 100L).let {
            if (nextStart != null) minOf(it, nextStart.coerceAtLeast(start + 100L)) else it
        }
        item.copy(start = start, end = end)
    }
}

private fun parseTime(value: String): Long? {
    val clean = value.trim().replace('.', ':')
    val parts = clean.split(":")
    return when (parts.size) {
        2 -> {
            val m = parts[0].toLongOrNull() ?: return null
            val s = parts[1].toLongOrNull() ?: return null
            (m * 60_000L) + (s * 1_000L)
        }
        3 -> {
            val h = parts[0].toLongOrNull() ?: return null
            val m = parts[1].toLongOrNull() ?: return null
            val s = parts[2].toLongOrNull() ?: return null
            (h * 3_600_000L) + (m * 60_000L) + (s * 1_000L)
        }
        else -> value.toLongOrNull()
    }
}

private fun time(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%02d:%02d".format(Locale.US, minutes, seconds)
}

private fun srtTime(ms: Long): String {
    val total = ms.coerceAtLeast(0L)
    val hours = total / 3_600_000L
    val minutes = (total / 60_000L) % 60L
    val seconds = (total / 1_000L) % 60L
    val millis = total % 1_000L
    return "%02d:%02d:%02d,%03d".format(
        Locale.US, hours, minutes, seconds, millis
    )
}

private fun captionsToSrt(captions: List<Caption>): String =
    buildString {
        captions.forEachIndexed { index, caption ->
            append(index + 1)
            append('\n')
            append(srtTime(caption.start))
            append(" --> ")
            append(srtTime(caption.end))
            append('\n')
            append(caption.text.trim())
            append("\n\n")
        }
    }
